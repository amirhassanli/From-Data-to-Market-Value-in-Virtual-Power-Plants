# DMDI codebook for the second coder (blinded double-coding)

Code each study in coder2_TEMPLATE.csv for the seven dimensions I,U,D,M,O,S,R using exactly one of E / P / NR, based on the FULL TEXT (including appendices/supplements where accessible). Do not look at any previous coding.

**TABLE III — DMDI DIMENSIONS AND CODING RULES**

| Dimension | Explicit (E) | Partial (P) | Not reported (NR) |
|---|---|---|---|
| I — Information-set integrity | Information available at each decision gate (forecast issue time, gate closure, known prices) is stated and no later data enter the decision | Information set partly stated or only implied | Not stated |
| U — Uncertainty integrity | Uncertainty model fitted to named empirical data and validated (calibration, coverage or dependence check) | Fitted without validation, or assumed with sensitivity analysis | Assumed without justification |
| D — Decision integrity | Objective, constraints and recourse fully specified and evaluated without look-ahead | Partly specified | Not specified |
| M — Market realism | Named real market with products, timing and clearing rules | Generic or stylized market | Not specified |
| O — Out-of-sample validity | Chronological split or rolling window, test period later than and disjoint from fitting, results reported on the held-out period | Temporal separation mentioned but incomplete or pooled with in-sample | Not discussed |
| S — Settlement realism | Reported profit or cost computed after a stated deviation or imbalance-settlement rule | Penalty term inside the objective or ex-ante deviation cost only | Not modeled |
| R — Reproducibility | A reader can rebuild the experiment from the stated data source, parameters and protocol without contacting the authors | Parameters or data partly reported | Not reported |


Notes: judge only what the paper reports. If the full text is not accessible, leave the row blank and tell us. Use the free-text column 'notes' for anything ambiguous.
