# Changelog (2026-11-08)
- Abstract aligned with Sec. 2.8 (Q1-Q8 applied illustratively to 3 studies).
- Ref [8] authors fixed: S. Kim and D. G. Choi (IDEAS/RePEc, POSTECH).
- Ref [44] authors fixed: Singh et al. (White Rose eprint 230118); Table IX updated.
- Table VIII Song et al. row -> [36] (PAB/PAC study).
- Sec. 10.3 maturity sentence made consistent with Tables VII-XI (max Level 4).
- All 19 uncited refs now cited (Sec. 3, 7, 8.1). 77/77 cited.
- Figures renumbered by order of appearance.
## Open items
Table I counts; Fig. 1 PRISMA regeneration; second coder (kappa); [44] full author list + DOI; Table X P row equals O row; NR-R/NR-U retag.
