**From Data to Market Value in Virtual Power Plants: A Structured Evidence Review of Decision Integrity, Uncertainty, and Electricity--Carbon Market Integration**

# Abstract

Virtual power plants (VPPs) are evolving from aggregation concepts into data-intensive decision systems that must coordinate heterogeneous distributed energy resources, forecasts, uncertainty, market participation, and increasingly carbon-related value streams. Existing reviews have substantially advanced the understanding of VPP architectures, data-driven energy management, uncertainty-aware bidding, real-world deployment, and electricity--carbon market coupling, but these strands are typically treated as separate methodological domains. This review shifts the unit of analysis from the individual algorithm to the complete data-to-market decision chain --- information acquisition, forecasting, uncertainty representation, optimization, bidding, market clearing, dispatch, deviation, settlement, and realized economic/carbon value --- and reports it as a structured, PRISMA-informed evidence review rather than as a fully database-frozen systematic review, because database-level identification, deduplication, and screening counts require institutional-account access that has not yet been completed (Section 2.4). A working candidate corpus of approximately 110 records was compiled; from it, 39 studies were independently verified against publisher metadata and coded for evidence synthesis (the "verified core"). The review introduces Data-to-Market Decision Integrity (DMDI) as a diagnostic evidence-coding instrument --- not a validated external standard --- spanning seven dimensions: information-set integrity, uncertainty integrity, decision integrity, market realism, out-of-sample validity, settlement realism, and reproducibility, each with an explicit coding rule and a four-level evidence status (Explicit / Partial / Not-Reported / Not-Verifiable). A companion, deliberately distinct risk-of-bias/evidence-quality layer is applied illustratively to three comparator studies and proposed for full study-level scoring. Within the verified core, decision integrity and market realism are comparatively well reported, whereas out-of-sample validity (2/39 explicit), settlement realism (4/39 explicit), and reproducibility (0/39 explicit) are the principal evidence bottlenecks --- a pattern we treat as indicative rather than final, pending completion of database-level screening and independent double-coding. Electricity--carbon market coupling is identified as an active but comparatively under-reviewed methodological frontier. The review closes with a research agenda emphasizing settlement-aware benchmarking, chronological out-of-sample evaluation as a reporting norm, explicit carbon-accounting-boundary reporting, and reproducibility (including inter-coder reliability) as first-class review evidence.

Index Terms---Virtual power plant, data-driven energy management, uncertainty representation, distributionally robust optimization, bidding strategy, carbon--electricity joint markets, out-of-sample validation, settlement realism, decision integrity, PRISMA, evidence review.

# 1. Introduction

Virtual power plants (VPPs) have become an important coordination paradigm for aggregating heterogeneous distributed energy resources (DERs), including renewable generation, battery energy storage systems (BESS), flexible commercial and industrial loads, electric vehicle (EV) fleets, and other controllable assets. The attraction of the VPP is not aggregation itself but the conversion of dispersed physical flexibility into coordinated operational and market value. This conversion increasingly depends on a data-intensive chain: measurements define the physical state of the portfolio, forecasts anticipate uncertain supply and demand, optimization converts information into operating schedules and bids, and market-clearing and settlement mechanisms ultimately determine whether the planned value is realized \[49\], \[50\], \[51\].

Recent reviews illustrate the breadth of this evolution. Ruan et al. \[1\] present a data-lifecycle perspective on VPP energy management spanning data creation, communication, decision support, privacy, learning methods, market participation, open datasets, and real-world projects. Gao et al. \[2\] focus on resource coordination and multidimensional VPP interaction. Kaiss et al. \[3\] survey VPP/virtual-aggregator concepts, architectures, and operation strategies. Esfahani et al. \[4\] map the transition from theoretical VPP models to real-world platforms and pilots, explicitly highlighting a persistent theory--practice gap. Zare et al. \[5\] propose a systematic market-coupling taxonomy classifying VPP interactions with electricity, flexibility, and carbon markets. These contributions establish a strong foundation, but they also expose a methodological question that has not, to our knowledge, been addressed as the central organizing question of a dedicated review: when a VPP study reports an improved forecast, a more sophisticated optimization objective, or a higher simulated profit, what evidence demonstrates that the resulting decision would have been valid at the time it was actually made, and that its value survives market clearing, physical deviation, and financial settlement?

This review addresses that question by treating VPP operation as an end-to-end decision chain --- Information → Forecast → Uncertainty → Decision → Bid → Clearing → Dispatch → Deviation → Settlement → Realized Value --- rather than as a set of independently evaluated modules. A forecasting model may have low error but provide little decision value; a stochastic optimization model may be mathematically sophisticated but rely on information unavailable at the decision time; a bidding strategy may show high in-sample profit while failing under temporally out-of-sample market conditions; and settlement-aware, market-realistic models may show smaller apparent gains while providing stronger evidence of deployability.

Building on this chain, the review introduces Data-to-Market Decision Integrity (DMDI) as a synthesis construct --- not an established standard --- organizing evidence along seven dimensions: information-set integrity, uncertainty integrity, decision integrity, market realism, out-of-sample validity, settlement realism, and reproducibility. The purpose is not to rank algorithms by a single score but to expose where evidence is present, partial, or absent along the decision chain, and to make that coding auditable by a third party.

## 1.1 Research questions

RQ1: How are data-driven VPP energy-management systems structured across the data-to-market decision chain? RQ2: How are uncertainty, dependence, and tail behavior represented and transferred from forecasting and scenario generation into VPP decisions? RQ3: To what extent does reported forecasting or AI performance translate into improved operational, bidding, and market outcomes? RQ4: How rigorously do existing VPP studies preserve information-set integrity, temporal causality, market timing, and out-of-sample validity? RQ5: How are electricity-market and carbon-market decisions coupled, and how do uncertainty and information quality propagate into economic and carbon outcomes? RQ6: What is the maturity of existing VPP research, from data-driven simulation to market-realistic, settlement-aware, and field-deployable operation?

## 1.2 Contribution and scope of claims

The contribution is fourfold. First, the review consolidates previously fragmented strands of VPP research into a common data-to-market decision chain. Second, it proposes DMDI as an auditable evidence-coding instrument, with explicit per-dimension coding rules (Section 5), rather than a conceptual taxonomy alone. Third, it separates forecast quality (FQ), decision quality (DQ), and realized market value (MV) as distinct, non-interchangeable evidence layers. Fourth, it develops a Data-to-Market Maturity Ladder distinguishing conceptual work from synthetic simulation, historical-data study, temporal out-of-sample study, market-realistic modeling, settlement-aware modeling, pilot validation, and operational deployment.

We are explicit about what this manuscript does not yet claim. It does not report a database-frozen PRISMA inclusion count (Section 2.4), it does not report inter-coder reliability statistics (Section 2.7, Section 11), and it does not claim that DMDI is a validated instrument outside this review. These boundaries are stated here so that every subsequent claim in the paper can be read against them.

# 2. Review Protocol

## 2.1 Review design and reporting standard

The review is designed as a structured literature review and reported in alignment with PRISMA 2020 \[6\] to the extent that available evidence supports it. PRISMA 2020 specifies a 27-item reporting checklist and a flow diagram for identification, screening, eligibility, and inclusion \[6\]. We use PRISMA as a reporting scaffold: where the underlying database-level records exist and are frozen, we report them in PRISMA form (Section 2.4); where they do not yet exist, we say so explicitly rather than estimating them. Because full database-level screening has not yet been completed and frozen, the manuscript is presented as a structured, PRISMA-informed evidence review rather than as a fully executed PRISMA systematic review. This is a deliberate title and framing choice (Section 2.9), not a cosmetic one: it is intended to prevent the manuscript from claiming a degree of database-level reproducibility it does not yet have.

## 2.2 Research questions and eligibility

Eligibility follows the research questions in Section 1.1. Studies are eligible when they are English-language, peer-reviewed journal papers or substantive peer-reviewed conference papers with direct relevance to VPP/virtual-aggregator energy management, scheduling, dispatch, bidding, flexibility coordination, uncertainty management, market participation, or deployment. Studies are excluded when VPP relevance is peripheral, energy-management evidence is absent, the contribution is a short abstract only, technical detail is insufficient for structured coding, or the record is a duplicate. Preprints are retained only as contextual leads unless independently verifiable against the criteria in Section 2.6.

## 2.3 Databases and explicit search strings

Principal databases: Scopus, Web of Science Core Collection, and IEEE Xplore. Principal review window: 2018--2026, with pre-2018 studies retained only as flagged foundational seed references for bidding formalism or architecture. The retrieval strategy is organized into six overlapping search blocks so that a single vocabulary choice (e.g., "data-driven VPP") does not exclude studies using adjacent terminology such as "virtual aggregator," "flexibility platform," or "stochastic bidding." The blocks and their exact Boolean strings, applied to title/abstract/keyword fields, are:

Block 1 --- Core VPP / aggregation terminology: `("virtual power plant" OR "VPP" OR "virtual aggregator" OR "flexibility aggregator")`

Block 2 --- Energy management, scheduling, and dispatch: `("energy management" OR "scheduling" OR "dispatch" OR "self-scheduling" OR "unit commitment")`

Block 3 --- Uncertainty and risk representation: `("uncertainty" OR "stochastic programming" OR "robust optimization" OR "distributionally robust" OR "polynomial chaos" OR "chance-constrained" OR "conditional value-at-risk" OR "CVaR" OR "risk-averse")`

Block 4 --- Data-driven and learning-based methods: `("deep learning" OR "reinforcement learning" OR "multi-agent reinforcement learning" OR "data-driven" OR "digital twin" OR "federated learning")`

Block 5 --- Electricity-market participation: `("bidding" OR "electricity market" OR "day-ahead market" OR "intraday market" OR "balancing market" OR "ancillary service" OR "reserve market" OR "imbalance settlement" OR "pay-as-bid" OR "pay-as-clear")`

Block 6 --- Carbon and environmental-instrument coupling: `("carbon market" OR "carbon trading" OR "carbon emission flow" OR "green certificate" OR "emission allowance")`

The retrieval query combines Block 1 AND Block 2 as the core VPP/energy-management filter, then separately intersects Block 1 with each of Blocks 3--6 to retrieve the uncertainty, AI, market, and carbon sub-literatures, respectively:

    S1 = Block1 AND Block2
    S2 = Block1 AND Block3
    S3 = Block1 AND Block4
    S4 = Block1 AND Block5
    S5 = Block1 AND Block6
    Working candidate corpus = S1 ∪ S2 ∪ S3 ∪ S4 ∪ S5, restricted to 2018–2026,
        English language, journal article or substantive conference paper.

### TABLE I --- Search execution log. Record counts and search dates are placeholders pending an institutional-account run and are not estimated.

  ------------------------------------------------------------------------------------------------------------------------
  Database                         Search string applied   Fields                    Search date       Records retrieved
  -------------------------------- ----------------------- ------------------------- ----------------- -------------------
  Scopus                           S1--S5 as above         Title/Abstract/Keywords   `n/r`             `n/r`

  Web of Science Core Collection   S1--S5 as above         Topic                     `n/r`             `n/r`

  IEEE Xplore                      S1--S5 as above         Full-Text & Metadata      `n/r`             `n/r`
  ------------------------------------------------------------------------------------------------------------------------

*The Boolean strings, field scope, and set-combination logic above are reproducible by any reviewer with database access. Record counts and exact search dates require an institutional-account run and are therefore reported as a disclosed placeholder rather than an estimated figure (Section 12).*

## 2.4 Study identification, screening, and the evidence-integrity boundary

Applying the retrieval strategy in Section 2.3 through available (non-institutional) search interfaces and citation-tracing from the seed reviews \[1\]--\[5\] produced a working candidate corpus of approximately 110 records. This candidate corpus is a working evidence pool, not a frozen PRISMA identification count, because deduplication, title/abstract screening, and full-text eligibility have not yet been executed and logged at the database level in a form that would allow independent reconstruction of the exact identification → screening → eligibility → inclusion counts required by PRISMA 2020 \[6\].

From the working candidate corpus, 39 studies were independently verified against publisher/DOI metadata and carried through full structured coding (Section 2.7); we refer to this set as the verified core. The verified core is the analytical corpus for every quantitative statement in Sections 7--10 of this review. We therefore describe the corpus precisely as: 39 studies independently verified for evidence synthesis from a working candidate corpus of approximately 110 records --- not as a final systematic-review inclusion sample.

Fig. 1 reports this flow in PRISMA-aligned box form, using the standard PRISMA 2020 stage names (Identification, Screening, Eligibility, Included) so that the boundary between what is frozen and what is not is visible in the same structure a completed PRISMA diagram would use. Boxes for which a count is not yet available are marked n/r and cross-referenced to Section 2.4 rather than populated with an estimated or reconstructed number.

Fig. 1. PRISMA 2020-aligned identification, screening, eligibility, and inclusion flow. Counts marked n/r are pending database screening (Table I) and are not estimated.

## 2.5 Data extraction fields

Each verified-core study is coded for: VPP architecture; DER composition; decision horizon; data source; forecasting method; uncertainty representation; dependence/scenario treatment; optimization paradigm; bidding mechanism; market products; carbon-integration level (Section 9.1); information-set definition; temporal split; out-of-sample testing; baseline quality; settlement model; computational reporting; reproducibility; deployment evidence; and Data-to-Market Maturity level (Section 10). A reference-verification status (Section 2.6) is maintained as a separate field so that bibliographic confidence is never conflated with methodological relevance.

## 2.6 Reference verification protocol

Every cited record was checked against at least one authoritative source --- publisher metadata, a DOI resolver, or an indexing service --- using a three-part check: (i) a metadata match for title, author list, venue, volume, and year; (ii) independent bibliographic cross-consistency across at least two records where available; and (iii) claim-to-source alignment, i.e. that any quantitative claim attributed to a source is actually present in it. Metadata checks were performed against Crossref DOI records and publisher landing pages. Records that could not be matched were removed before submission rather than retained with a caveat. Bibliographic verification is maintained as a coding field separate from methodological relevance (Section 2.5), so that bibliographic confidence is never conflated with methodological relevance.

## 2.7 Structured coding roles and AI-assisted coding disclosure

Literature identification, reference verification, and first-pass evidence coding for this review were structured around eight predefined analytical coding roles, used to divide the audit into tractable, cross-checked sub-tasks: (A) VPP concepts and architecture; (B) uncertainty, risk, and bidding; (C) data-driven and AI methods; (D) electricity, flexibility, and carbon markets; (E) deployment and practical barriers; (F) the complete decision chain; (G) evidence quality and validation; (H) reference verification. These are coding roles applied with the assistance of a large language model under direct researcher supervision, not independent human reviewers or a claim of formal inter-rater methodology; every output produced under a role was reconciled by the authors into a single study-level evidence matrix, and every reference appearing in the final list (Section 14) was individually cross-checked against a primary bibliographic source before inclusion (Section 2.6). This disclosure is made in accordance with IEEE author guidelines on the use of AI-generated content in submitted articles.

We flag explicitly, as a limitation rather than an omission, that this structured-coding process has not yet been validated by independent double-coding (e.g., a second, blinded human coder reproducing the DMDI ratings in Table X and computing agreement such as Cohen's κ). Reporting that the literature shows low explicit reproducibility (Section 10) while not yet demonstrating the reproducibility of our own coding process would be an internal inconsistency if left unaddressed; we therefore treat single-coder DMDI ratings as provisional and indicative, name double-coding as a required next step (Section 11.6, Section 12), and avoid any composite scoring that would present the current ratings as more settled than they are.

## 2.8 Risk-of-bias / evidence-quality layer (distinct from DMDI)

DMDI (Section 5) codes *what evidence a study provides along the decision chain*; it is not a risk-of-bias instrument and does not assess study quality independent of the chain. We therefore define a second, deliberately separate evidence-quality layer, adapted from PRISMA's expectation that a systematic review report how study-level quality was assessed \[6\]:

  -------------------------------------------------------------------------------------------------------------------------------------------------------------
  ID   Question                   What counts as satisfied
  ---- -------------------------- -----------------------------------------------------------------------------------------------------------------------------
  Q1   Search/data transparency   Data source, horizon, and any pre-processing are stated in enough detail to identify the dataset

  Q2   Information-set validity   The paper states what information was available at each decision gate (see coding rule for I, Section 5)

  Q3   Temporal validation        Train/validation/test split is chronological, not random, for time-dependent series

  Q4   Baseline adequacy          At least one transparent, non-trivial baseline is reported alongside the proposed method

  Q5   Market realism             Market rules (products, timing, clearing) match a named, real jurisdictional mechanism or are explicitly stated as stylized

  Q6   Settlement realism         Deviation, imbalance, or penalty/reward mechanisms are modeled, not only the ex-ante objective value

  Q7   Reproducibility            Code, data, or sufficient parameterization is available or described for independent replication

  Q8   Reporting completeness     Sample size / scenario count / computational effort are reported
  -------------------------------------------------------------------------------------------------------------------------------------------------------------

The Q1--Q8 layer is applied qualitatively to the three comparator studies in Table VII; full scoring of the verified core is left to future work, because scoring 39 studies without a second coder would reproduce the single-coder limitation identified in Section 2.7.

## 2.9 Reporting status of the evidence synthesis

This review is reported as a structured evidence review rather than as a completed PRISMA 2020 systematic review. Three elements of a full systematic review are reported in full: the eligibility criteria (Section 2.2), the retrieval logic and Boolean strings (Section 2.3), and the reference-verification procedure (Section 2.6). Three elements are not yet complete and are stated as limitations rather than estimated: database-level identification and screening counts (Sections 2.4 and 12); independent double-coding of the DMDI ratings (Sections 2.7 and 11.6); and retrospective re-tagging of the existing not-reported entries into NR-R and NR-U (Section 5.3). Where a reported quantity depends on one of these unfinished steps --- notably the per-dimension counts in Table X --- it is described as indicative of a pattern rather than as a prevalence estimate.

# 3. Existing Review Landscape

Table II positions this review against the principal prior reviews and against representative primary studies that anticipate parts of the decision-chain argument. The comparison is between literature lenses, not between review rankings: we do not claim novelty from combining topics that have already been reviewed separately, but from adding an explicit information-to-settlement evidence audit on top of them. Beyond the five anchor reviews, further recent reviews cover complementary angles: VPP models and electricity markets \[7\]; deep-reinforcement-learning bidding in spot markets \[32\]; deep learning \[33\] and AI-driven VPPs \[34\]; uncertainty management and market bidding strategies \[48\]; policy and regulation \[35\]; and net-zero grids with blockchain integration \[39\] and distributed renewable projects in the built environment \[40\]. To our knowledge, none of these takes a study-level information-to-settlement evidence audit as its organizing unit.

### TABLE II --- Literature streams and positioning of this review

  ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  Literature stream                         Representative evidence                                                               Primary contribution                                          What is validated                                   Limitation relative to DMDI
  ----------------------------------------- ------------------------------------------------------------------------------------- ------------------------------------------------------------- --------------------------------------------------- --------------------------------------------------------------------------
  Data-driven reviews                       Ruan et al. \[1\]                                                                     Data lifecycle, AI, privacy, market participation             Broad thematic coverage                             Not a study-level information-to-settlement audit

  Architecture/operation reviews            Gao et al. \[2\]; Kaiss et al. \[3\]                                                  VPP coordination, operation, markets, ancillary services      Architectural and operational breadth               Evidence not normalized by decision-time information

  Theory-to-practice reviews                Esfahani et al. \[4\]                                                                 Platforms, pilots, real-world implementations                 Deployment evidence                                 Case heterogeneity limits direct methodological comparison

  Market/carbon review                      Zare et al. \[5\]; carbon-review evidence \[38\]                                      Electricity, flexibility, carbon market-coupling taxonomies   Market-coupling and carbon-flow taxonomies          Settlement and information-set integrity are not the central coding unit

  Sequential stochastic bidding (primary)   Wozabal & Rameseder \[9\]                                                             Day-ahead + multi-auction intraday bidding, OOS comparison    Market-timing and out-of-sample value               Settlement mechanics require separate audit

  Risk-aware scheduling (primary)           Vahedipour-Dahraie et al. \[10\]                                                      CVaR, demand response, reserve, N-1                           Risk-sensitive operational decisions                Empirical OOS and settlement evidence remain limited

  AI forecasting/bidding (primary)          Sadeghi et al. \[11\], \[12\]; Wang et al. \[19\]; Nadimi & Goto \[29\], \[30\]       Deep-learning forecasting and decision support                Forecast/policy performance                         Forecast-to-market-value transfer not uniformly established

  DRO/robust bidding (primary)              Li \[22\]; internal/external DRO \[26\]; Song et al. \[28\]; interval-robust \[27\]   Ambiguity-set, multi-uncertainty bidding                      Robust decision quality under modeled uncertainty   Calibration and real settlement remain uneven

  MARL/DRL (primary)                        Wang et al. \[14\]; Xu et al. \[23\]; Wu et al. \[24\]                                Autonomous/decentralized decision-making                      Policy performance and coordination                 Temporal generalization and market realism vary

  Electricity--carbon coupling (primary)    Liu \[13\]; Liu et al. \[20\]; Wang et al. \[21\]; Bian et al. \[31\]                 Joint electricity--carbon bidding/scheduling                  Economic/environmental coupling                     Accounting, decision, and settlement coupling not always separated

  Settlement/market mechanism (primary)     PAB/PAC study \[36\]; DER portfolio study \[37\]                                      Auction and imbalance effects                                 Direct market/settlement sensitivity                Smaller literature than optimization-focused work
  ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# 4. Synthesis Streams and Retrieval Blocks

The six retrieval blocks in Section 2.3 exist to maximize recall during search (so that uncertainty, AI, market, and carbon vocabulary are each retrieved even when a study does not use the phrase "VPP energy management" directly). They are a search-execution device, not a synthesis structure. For synthesis, the verified core is organized into five thematic streams, which is the level at which Sections 7--10 report results:

1.  Concept/architecture --- VPP definitions, DER composition, coordination structures.
2.  Uncertainty/risk --- stochastic, robust, DRO, and risk-averse representations and their calibration.
3.  Data-driven/AI --- forecasting, deep learning, reinforcement learning, and hybrid learning--optimization methods.
4.  Market/carbon --- electricity-market products, settlement mechanisms, and carbon/green-certificate coupling.
5.  Practical deployment --- pilot, hardware-in-the-loop, and field-operational evidence.

Every verified-core study is tagged to at least one synthesis stream independently of which retrieval block(s) originally surfaced it, since a study retrieved via the carbon block, for example, may be synthesized primarily under uncertainty/risk if that is its main methodological contribution.

# 5. The DMDI Framework

![](media/image2.png){width="6.5in" height="2.1708333333333334in"}

Fig. 2. Data-to-Market Decision Integrity (DMDI) chain.

## 5.1 The decision chain and seven dimensions

VPP decision-making is treated as a continuous chain: Information → Forecast → Uncertainty → Decision → Bid → Clearing → Dispatch → Deviation → Settlement → Realized Value (Fig. 2). DMDI comprises seven evidence dimensions along this chain:

1.  Information-set integrity (I) --- whether the study uses only information genuinely available at the decision gate being modeled.
2.  Uncertainty integrity (U) --- whether uncertainty distributions, dependence, scenarios, and tails are empirically justified rather than merely assumed.
3.  Decision integrity (D) --- whether the optimization or learning policy is evaluated under its own stated constraints, without look-ahead bias.
4.  Market realism (M) --- whether market products, timing, clearing rules, and strategic assumptions correspond to a defined, named market setting.
5.  Out-of-sample validity (O) --- whether performance is evaluated on chronologically unseen conditions rather than random splits or in-sample data.
6.  Settlement realism (S) --- whether realized value is computed through a credible settlement mechanism (deviations, imbalance penalties/rewards), not only the ex-ante objective value.
7.  Reproducibility (R) --- whether data provenance, parameters, baselines, and evaluation procedures are reported in enough detail for independent reconstruction.

Deployment maturity is tracked as a companion field, P (Section 10), because operational evidence cannot be inferred from methodological sophistication alone.

## 5.2 Explicit coding rules

Each dimension is coded on a four-level evidence status: Explicit, Partial, NR-R (not reported), or NR-U (not verifiable from the available evidence, e.g., because full text was inaccessible or the claim could not be checked against a primary source). Coding rules, illustrated using out-of-sample validity as the worked example:

-   O = Explicit if all three hold: (i) a chronological train/validation/test split or rolling-window evaluation is used; (ii) the test period is disjoint from and later than any period used for fitting/tuning; (iii) quantitative performance is reported specifically on that held-out period.
-   O = Partial if temporal separation is mentioned but at least one of (ii)--(iii) is missing or ambiguous (e.g., the split is described only qualitatively, or results pool in-sample and out-of-sample periods).
-   O = NR-R if the paper does not discuss temporal separation at all and does not claim otherwise.
-   O = NR-U if the paper's description is too incomplete (e.g., abstract-only access) to determine which of the above applies.

Analogous rules apply to the other six dimensions, substituting the relevant chain-link criteria --- for example, S = Explicit requires that reported profit/cost figures are computed after applying a stated deviation or imbalance-settlement rule (not the optimization objective value alone), and R = Explicit requires that a reader could, in principle, reconstruct the reported experiment from the paper's stated data source, parameters, and evaluation protocol without contacting the authors.

## 5.3 On NR-R vs. NR-U

"Not reported" conflates several different situations: a study may be silent on a dimension, or the dimension may not be determinable from the accessible text. The distinction is applied to all coding performed for this review. Disaggregating the NR entries already present in the Sections 7--10 tables into NR-R versus NR-U would require re-reading each of the affected primary sources against the two-way rule; this re-tagging pass has not yet been completed (Section 11.6). Table X (Section 10) therefore reports a single combined NR column for the existing 39-study matrix, with the caveat stated here, while all tables introduced with the four-level scheme (e.g., Table VII) use it directly.

DMDI is intentionally not collapsed into a single numerical score. This avoids arbitrary dimension weights and prevents strong evidence on one dimension from masking a critical gap on another. The preferred presentation throughout is a dimension-by-dimension evidence matrix (Fig. 5) supplemented by the maturity ladder (Section 10).

# 6. Decision Integrity: A Complementary Four-Layer Framework

## 6.1 Two instruments, two questions

This review uses two deliberately separate instruments, because they answer two different questions and rest on two different evidence bases. DMDI (Section 5) is an evidence-coding instrument applied per study along the data-to-market decision chain: it answers "what evidence does this specific paper provide?" The Decision Integrity framework introduced in this section is a conceptual threat-and-countermeasure taxonomy applied at the level of the literature as a whole: it answers "independent of what any given paper reports, what could cause a market-facing VPP decision to be wrong, unstable, or untrustworthy, and how mature are the available defenses?" Threats such as corrupted telemetry, adversarially perturbed forecasts, opaque bidding agents, and unverifiable carbon accounting are rarely the explicit subject of a bidding or scheduling paper, yet they bound how much confidence the field should place in a paper\'s reported value even when its DMDI ratings are strong.

Decision Integrity is therefore defined as the property that a VPP\'s market-facing decisions (bids, offers, schedules, and control setpoints) remain correct (consistent with true system state and market rules), robust (stable under uncertainty and distributional shift), and trustworthy (verifiable, explainable, and auditable) despite imperfect, incomplete, or adversarially manipulated inputs. It is organized into four layers --- data, model, execution, and governance --- each with representative threats and countermeasures rated by maturity. Table III is a qualitative, literature-wide judgment by the authors, informed by the cybersecurity, robust-optimization, privacy, and market-design literatures cited throughout this section; it is not a re-coding of the 39-study verified core and does not carry the same evidentiary status as the DMDI tables in Sections 7--10 (Section 12).

The two instruments are complementary rather than overlapping: DMDI's Information-set (I) and Reproducibility (R) dimensions correspond most closely to the Data (L1) and Governance (L4) layers below; DMDI's Uncertainty (U) and Decision (D) dimensions correspond most closely to the Model layer (L2); and DMDI's Market (M) and Settlement (S) dimensions correspond most closely to the Execution layer (L3). Where DMDI shows a literature-wide gap (Section 10.1: O, S, and R are weak), the Decision Integrity layers below make explicit *why* such gaps are consequential and *what* would close them.

## 6.2 The four layers

### TABLE III --- Decision-integrity threats and countermeasures by layer (qualitative, literature-wide)

  -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  Layer            Integrity question             Representative threats                                                                                                                     Countermeasures (maturity)
  ---------------- ------------------------------ ------------------------------------------------------------------------------------------------------------------------------------------ ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  L1: Data         Do inputs reflect reality?     Missing/corrupt telemetry; false data injection (FDI) \[56\], \[57\]; clock skew; meter tampering                                          Bad-data detection, robust state estimation (high); FDI detectors, physics-informed validation (medium); redundancy and attestation (medium)

  L2: Model        Do models stay valid?          Distributional shift invalidating scenario sets; adversarial perturbation of learned forecasters/bidders \[58\]; miscalibration; opacity   Proper scoring rules and calibration diagnostics (high); distributionally robust optimization \[64\] and adversarial training (medium); post-hoc explainability, SHAP \[59\]/LIME \[60\] (medium--low); digital-twin stress testing \[62\] (low--medium)

  L3: Execution    Are market actions faithful?   Network-infeasible offers; market-power abuse in thin markets; carbon-baseline gaming; settlement disputes                                 Pre-submission feasibility screening (high); market monitoring (high); ledger-anchored settlement and audit trails \[63\] (medium); strategy explainability (low)

  L4: Governance   Can decisions be audited?      Opaque AI bidders; prosumer privacy exposure; unverifiable MRV (measurement, reporting, verification) for carbon claims                    Logging and reproducibility standards (medium); federated learning \[61\] with differential privacy (medium); regulatory compliance, e.g., GDPR-type regimes (high); ledger-based MRV trails \[63\] (medium--low)
  -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

The layers are ordered by proximity to raw data, but failures propagate both upward (bad data corrupts bids) and downward (unverifiable markets invite data manipulation). A distinction worth making explicit within L1: generic state-estimation FDI research asks whether an attack evades a residual-based bad-data detector, whereas a more recent, market-specific strand asks whether an attack is *profitable* under the two-settlement market design itself --- i.e., whether the attacker's objective is stated directly in market currency rather than in generic system-cost terms \[75\]. This reframing matters for VPPs specifically, because it converts data integrity from a physical-security question into the same market-currency terms used elsewhere in this review's Decision Integrity accounting, and it is the reasoning behind treating L1 as a market property rather than a purely engineering one (Section 6.1). Solution technologies cut across layers: decomposition methods such as ADMM \[65\] and Benders decomposition \[66\] support scalable, privacy-preserving coordination (L1/L4), while game-theoretic tools --- Nash equilibrium analysis \[67\] and Shapley-value surplus sharing \[68\] --- support execution-layer (L3) monitoring of strategic behavior in coupled or thin markets.

## 6.3 Uncertainty taxonomy and decision paradigms

To complement DMDI's per-study Uncertainty (U) and Decision (D) coding (Section 8.1) with a literature-wide conceptual map, Table IV classifies VPP uncertainty sources by timescale and character, and Table V compares six decision paradigms on the dimensions that determine what market value each can credibly promise.

### TABLE IV --- Taxonomy of VPP uncertainties

  ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  Source                                Timescale        Character                                 Standard treatment
  ------------------------------------- ---------------- ----------------------------------------- -----------------------------------------------------------------------------------
  Wind/solar output                     Minutes--days    Aleatoric, correlated, non-Gaussian       Probabilistic forecasts; scenario generation; storage buffering

  Load and prosumer behavior            Minutes--days    Partly epistemic, behavioral              Probabilistic load forecasting; demand-response contracts

  Day-ahead/intraday/balancing prices   Hours--days      Strategic, fat-tailed, regime-switching   Scenario trees; price-arbitrage recourse across market floors

  Carbon/allowance prices               Days--years      Policy-driven, jump-prone                 Hedging; tiered trading; energy--carbon co-optimization

  Outages and contingencies             Seconds--hours   Rare, high-impact                         Reserve procurement; CVaR-based tail control \[69\]

  Model and parameter error             All              Epistemic                                 Robust/distributionally robust ambiguity sets \[64\]; info-gap satisficing \[70\]
  ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

### TABLE V --- Decision paradigms for VPPs under uncertainty

  ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  Paradigm                                     Uncertainty input                Guarantee / objective                                          Cost and data appetite
  -------------------------------------------- -------------------------------- -------------------------------------------------------------- -------------------------------------------------------------
  Deterministic + point estimate               Point forecast (+ moments)       Optimal for the nominal case                                   Low cost; fragile to tail events

  Stochastic programming (SP)                  Scenarios with probabilities     Optimal in expectation; explicit recourse                      High (scenario growth); needs credible distributions \[71\]

  Chance-constrained programming (CCP)         Distributions                    Feasibility with probability 1−ε                               Medium; tractable mainly for Gaussian/affine cases \[72\]

  (Adaptive) robust optimization (RO/ARO)      Uncertainty sets                 Feasible for all realizations in the set; worst-case optimal   Medium; conservative unless the set is tuned \[73\], \[74\]

  Distributionally robust optimization (DRO)   Ambiguity set of distributions   Worst-case expectation over plausible distributions            Medium--high; data-driven calibration \[64\]

  Info-gap decision theory (IGDT)              Horizon of uncertainty           Maximum robustness to severe, non-probabilistic uncertainty    Low--medium; no probability distribution required \[70\]
  ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

No paradigm dominates: SP maximizes expected value when scenario distributions are trustworthy but degrades when they are not; RO/DRO purchase reliability at a measurable "price of robustness" \[73\]; IGDT protects against genuinely unknown uncertainty horizons (e.g., unprecedented carbon-price regimes) but offers no expected-value optimality claim. Read against DMDI, paradigm choice is itself an information-integrity commitment: each paradigm makes a different promise about what it does not know, and the DMDI Uncertainty (U) and Decision (D) ratings in Table VII (Section 8.1) should be interpreted in light of which promise a given study is making, not compared as if all six paradigms targeted the same guarantee.

## 6.4 Electricity--carbon coupling archetypes

Section 9.1 codes, per study, how deeply a given paper integrates carbon accounting into its decision model (a six-level *evidence* scale). Table VI complements this with a six-archetype *mechanism-design* taxonomy describing how the electricity--carbon literature as a whole structures the coupling, ordered by integration depth.

### TABLE VI --- Electricity--carbon coupling archetypes

  -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  \#   Archetype                                Mechanism                                                                      Strengths                                                              Integrity/risk caveats
  ---- ---------------------------------------- ------------------------------------------------------------------------------ ---------------------------------------------------------------------- ---------------------------------------------------------------------
  A1   Exogenous carbon adder                   A carbon price is added to fossil marginal cost outside the decision model     Simple; compatible with existing dispatch logic                        Ignores carbon-price uncertainty; no MRV feedback loop

  A2   Emission-flow accounting                 Network carbon intensities are attributed to loads/VPP nodes                   Physically grounded; enables nodal carbon signals                      Depends on flow-data integrity; allocation-rule disputes

  A3   Sequential two-stage trading             Electricity is cleared first, carbon settled afterward on a separate cadence   Matches real market tempos; computationally tractable                  Post-hoc carbon settlement provides weak dispatch-time incentive

  A4   Hierarchical co-optimization             Leader--follower or bi-level electricity--carbon coordination                  Captures strategic interaction between markets                         Computationally heavy; equilibrium-selection issues

  A5   Joint clearing / energy-credit markets   Energy and environmental value are co-cleared in a single mechanism            Strongest incentive alignment between electricity and carbon signals   Nascent market design; liquidity and market-power concerns

  A6   Tiered (ladder) carbon pricing           Marginal carbon price rises with emission bands                                Rewards deep emissions cuts progressively                              Baseline-setting integrity is decisive; gaming-prone if MRV is weak
  -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

The verified-core evidence in Table IX (Section 9.1) concentrates at A1--A3: exogenous adders and emission-flow accounting are common, and sequential two-stage trading appears in several recent studies \[13\], \[20\], \[25\]. Deeper integration (A4--A6) --- bi-level coordination, joint energy-credit clearing, and tiered pricing --- appears mostly in the most recent studies \[31\], \[43\], \[44\] and aligns with the review-level observation in Section 9.2 that carbon--electricity coupling methodology is still consolidating. Every coupling archetype ultimately rests on MRV integrity (Table III, L4): without trustworthy emission attribution, carbon-coupled VPP revenue rests on an unverifiable foundation, regardless of how sophisticated the coupling mechanism is.

## 6.5 Enabling technologies and their integrity/maturity trade-offs

Four technology families recur across the Decision Integrity literature, each trading value for a distinct integrity cost:

-   Reinforcement learning for forecasting and bidding. RL and deep-learning bidding agents adapt to nonstationary prices and behavior that static scenario sets miss, but they are comparatively opaque and can be destabilized by adversarial or out-of-distribution inputs \[58\]; constrained and explainable RL variants are an active bridge technology.
-   Distributed optimization and decomposition. ADMM-based coordination \[65\] and Benders decomposition \[66\] let large, heterogeneous DER portfolios be optimized without a single centralized model of every asset, simultaneously improving scalability, privacy (L4), and resilience to single points of failure --- a rare case where a value-driven technique also improves integrity.
-   Blockchain and smart-contract settlement. Ledger-anchored logs of offers, meter readings, and carbon-credit transfers make ex-post verification cheap \[63\], directly supporting L3/L4 auditability; throughput, energy cost, and the "oracle problem" (a ledger cannot verify off-chain meter truth on its own) keep maturity medium--low.
-   Digital twins and federated/privacy-preserving learning. High-fidelity replicas of VPP portfolios support pre-market stress-testing of bidding policies under simulated attack or drift \[62\]; federated learning \[61\] allows prosumer-level models to train without raw-data egress, addressing the privacy tension in L4 governance.

The pattern across these technologies mirrors the DMDI finding in Section 10.1: technologies closest to raw market value (forecasting, RL bidding) matured first, while integrity-enabling technologies (explainability, ledger-anchored audit, federated/privacy-preserving coordination) remain comparatively immature --- the same information-to-settlement and execution-to-governance imbalance, seen here from a technology-maturity angle rather than a per-study evidence angle.

# 7. Results: Information and Forecast Integrity

Across the verified core, information-set integrity (I) is the dimension most consistently reported: 22 of 39 studies (56%) provide explicit information-set definitions (measurement timestamps, forecast publication time, or market gate closure), and a further 17 provide partial evidence, with no study coded NR on this dimension. This is consistent with the fact that most bidding and scheduling formulations must, by construction, state what is known at the bidding stage even if they do not audit it against real-world timing.

Forecast integrity is treated in this review as an intermediate metric, not an endpoint. Recent forecasting work addresses data scarcity through transfer-learning and adversarial graph mechanisms for distributed PV \[19\], long-horizon recursive forecasting via BiLSTM-based decision support \[30\], and explicit uncertainty reduction from day-ahead to balancing markets \[29\]. These studies strengthen the forecasting layer, but their contribution to realized market value must be judged by whether the forecast improvement changes the resulting bidding decision under the same information set --- the FQ → UQ → DQ → MV distinction used throughout this review (Section 1). A forecasting paper reporting lower MAE without a demonstrated operational or bidding consequence is classified as predictive evidence only, not market-value evidence. The forecast-to-decision link is addressed more directly by studies that carry comprehensive forecasting error into the storage-allocation and spot-market bidding stage \[18\] and by a closed-loop framework that couples forecasting and bidding \[47\]; these are the study types for which the FQ → DQ → MV question can in principle be answered, provided the reported value is a settled rather than an objective-function value (Section 8.3). On the demand side, a data-mining-driven incentive-based demand-response scheme \[55\] illustrates how learned consumer-behavior models enter VPP operation as an information input whose decision-time availability must likewise be stated.

# 8. Results: Uncertainty, Decision, and Market/Settlement Integrity

## 8.1 Uncertainty and decision integrity

The literature shows a clear methodological progression from deterministic scheduling toward stochastic programming (scenario trees) \[10\], \[16\], through robust optimization, to distributionally robust optimization (DRO), increasingly Wasserstein-metric-based and dominant since approximately 2023 \[22\], \[25\]--\[28\]. Complementary primary studies illustrate the breadth of formulations: two-stage robust scheduling with responsiveness-based EV aggregation \[15\]; day-ahead bidding of renewable-based VPPs \[17\]; operation in a frequency-constrained market \[52\]; bi-level multi-objective strategic bidding \[53\]; price-maker bidding with interval optimization \[54\]; data-driven DRO co-optimization of energy, frequency regulation, and voltage support \[41\]; hierarchical DRL energy management of aggregated microgrids \[42\]; and coordination through locational marginal flexibility under network constraints \[46\]. Their position on each DMDI dimension is determined by the same coding rules (Section 5.2) rather than by method family. Decision integrity (D) is well reported overall (32/39 explicit, 7/39 partial, 0 NR), reflecting that most optimization-focused papers do specify their constraint sets; market realism (M) is similarly strong (31/39 explicit, 8/39 partial). Uncertainty integrity (U) is explicit in 23/39 studies and partial in 15/39, with one NR.

However, methodological sophistication in uncertainty representation does not by itself establish uncertainty *validity*. Three distinctions matter. First, uncertainty representation differs from uncertainty calibration: a Gaussian or empirical distribution can be embedded in an optimization model without demonstrating that it reproduces the relevant error distribution. Second, marginal accuracy differs from dependence integrity: separately calibrated wind, PV, load, and price distributions may fail to reproduce cross-variable and temporal dependence. Third, in-sample risk control differs from out-of-sample risk control: a risk measure such as CVaR is decision-relevant only when the loss distribution used for evaluation reflects the conditions encountered after the bid or schedule is fixed.

### TABLE VII --- Comparative evidence for uncertainty transfer and decision integrity (illustrative Q1--Q8 tags shown for the three most methodologically distinct entries)

  ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  Study                                     Uncertainty method                   U          D          I          OOS        Maturity   Q1--Q8 (illustrative)
  ----------------------------------------- ------------------------------------ ---------- ---------- ---------- ---------- ---------- ----------------------------------------
  Wozabal & Rameseder (2020) \[9\]          Multi-stage stochastic               Explicit   Explicit   Explicit   Explicit   Level 4    Q1--Q5 met; Q6 partial; Q7 partial

  Vahedipour-Dahraie et al. (2020) \[10\]   Stochastic + CVaR                    Explicit   Explicit   Partial    NR         Level 1    ---

  Falabretti et al. (2023) \[16\]           Stochastic + rolling horizon         Explicit   Explicit   Explicit   Partial    Level 4    ---

  Fan & Liu (2024) \[25\]                   Wasserstein DRO + DRCC               Explicit   Explicit   Explicit   NR         Level 2    Q1, Q2, Q5 met; Q6 partial; Q7 not met

  Li (2024) \[22\]                          Semi-anticipative DRO                Explicit   Explicit   Explicit   NR         Level 3    ---

  Kim & Choi (2024) \[8\]                   Sample-robust + real business data   Explicit   Explicit   Explicit   Explicit   Level 4    Q1--Q4 met; Q6 partial; Q7 partial

  Ma et al. (2025) \[27\]                   Data-driven interval robust          Explicit   Explicit   Explicit   NR         Level 3    ---

  Song et al. (2025) \[28\]                 DRO + discrete scenarios             Explicit   Explicit   Explicit   NR         Level 3    ---

  Bian et al. (2026) \[31\]                 CVaR + energy/regulation/carbon      Explicit   Explicit   Explicit   NR         Level 2    ---
  ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

## 8.2 Market and settlement integrity

Market realism is comparatively well established, but settlement realism (S) is markedly weaker: 4/39 studies explicit, 18/39 partial, 17/39 NR. Market-mechanism studies that explicitly model pay-as-bid/pay-as-clear rules and imbalance penalties \[36\], and portfolio-composition studies that link DER composition to settlement outcomes \[37\], illustrate why settlement deserves independent treatment from market-clearing realism: a study can model realistic clearing (M = Explicit) while still computing reported profit from the ex-ante objective rather than from post-deviation settlement (S = Partial or NR).

### TABLE VIII --- Electricity-market, settlement, and carbon-market evidence

  ----------------------------------------------------------------------------------------------------------------------------------------------
  Study                              Market structure                                              Settlement   Carbon     OOS        Maturity
  ---------------------------------- ------------------------------------------------------------- ------------ ---------- ---------- ----------
  Wozabal & Rameseder (2020) \[9\]   Day-ahead + six intraday auctions                             Partial      NR         Explicit   Level 4

  Liu (2022) \[13\]                  Electricity + intraday DR + regulation + real-time + carbon   Partial      Explicit   NR         Level 1

  Fan & Liu (2024) \[25\]            Electricity--carbon coupled market                            Explicit     Explicit   NR         Level 2

  Liu et al. (2024) \[20\]           Electricity--carbon joint + CCER + DR                         Partial      Explicit   NR         Level 1

  Song et al. (2025) \[36\]          Pay-as-bid / pay-as-clear + imbalance penalties               Explicit     NR         NR         Level 1

  Kim & Choi (2024) \[8\]            Wholesale, settlement-aware DER portfolio design              Explicit     NR         NR         Level 2

  Bian et al. (2026) \[31\]          Energy + regulation + carbon                                  Partial      Explicit   NR         Level 2
  ----------------------------------------------------------------------------------------------------------------------------------------------

## 8.3 The Optimization-to-Settlement Evidence Gap

The single most consequential pattern in Sections 8.1--8.2, in our reading, is that the chain Objective value → Cleared value → Delivered value → Settled value is rarely reported in full. Of the verified core, most uncertainty-handling and market studies report objective-function or cleared-market value; substantially fewer report the value that would remain after physical deviations and settlement penalties are applied (S explicit in only 4/39 studies). This is not evidence that reported gains are wrong --- many studies explicitly and reasonably target theoretical upper-bound performance rather than deployment-readiness --- but it means that a reported "profit improvement" should be read, by default, as an *objective-value* or *cleared-value* claim unless the study explicitly states otherwise. We treat this Optimization-to-Settlement Evidence Gap as a central, citable finding of this review (see also Section 10.1) rather than an incidental observation, and recommend that future studies report which of the four stages their headline number corresponds to.

![Fig. 3. Forecast-to-Value and Optimization-to-Settlement evidence map.](media/image3.png){width="5.833333333333333in" height="3.802179571303587in"}

Fig. 3. Forecast-to-Value and Optimization-to-Settlement evidence map.

# 9. Results: Electricity--Carbon Market Integration

## 9.1 A six-level carbon-coupling coding scheme

Carbon integration is often recorded only as present or absent in the objective function, which is too coarse for a review organized around the decision chain. We therefore use an explicit six-level coding scheme, applied qualitatively to the carbon-relevant verified-core studies:

1.  Accounting coupling --- a carbon emission factor or intensity is reported or referenced, without appearing in the decision model.
2.  Objective coupling --- a carbon cost or revenue term appears in the objective function.
3.  Constraint coupling --- carbon emissions or allowances appear as an explicit constraint (e.g., an emissions cap).
4.  Market-participation coupling --- the VPP explicitly participates in a modeled carbon-trading or green-certificate market alongside electricity markets.
5.  Clearing coupling --- carbon-market clearing (price formation, allocation) is modeled with its own mechanism rather than treated as an exogenous price series.
6.  Settlement/coupled-decision coupling --- realized carbon value is computed after settlement, and the electricity and carbon decisions are shown to interact (e.g., a carbon-price change is shown to alter the electricity bid).

### TABLE IX --- Carbon-coupling level of representative studies

  ----------------------------------------------------------------------------------------------------------------------------------
  Study                        Accounting   Objective   Constraint   Market participation   Clearing   Settlement/coupled decision
  ---------------------------- ------------ ----------- ------------ ---------------------- ---------- -----------------------------
  Liu (2022) \[13\]            ✓            ✓           ✓            ✓                      Partial    Partial

  Liu et al. (2024) \[20\]     ✓            ✓           ✓            ✓                      Partial    NR

  Wang et al. (2024) \[21\]    ✓            ✓           ✓            Partial                NR         NR

  Fan & Liu (2024) \[25\]      ✓            ✓           ✓            ✓                      Partial    Partial

  Bian et al. (2026) \[31\]    ✓            ✓           ✓            ✓                      Partial    NR

  Siqin et al. (2025) \[43\]   ✓            ✓           ✓            ✓                      Partial    NR

  Singh et al. (2025) \[44\]   ✓            ✓           Partial      ✓                      NR         NR
  ----------------------------------------------------------------------------------------------------------------------------------

![](media/image4.png){width="6.5in" height="2.1729166666666666in"}

Fig. 4. Electricity--carbon value propagation.

Most carbon-integrated studies reach Level 2--4 (objective, constraint, and market-participation coupling); very few reach Level 5--6. This indicates that the field has moved well beyond treating carbon as a static accounting term, but has not yet widely demonstrated that carbon-market clearing and settlement interact dynamically with the electricity-side decision --- the gap identified at the review level by \[5\] and \[38\] and echoed in the primary literature surveyed here.

This six-level accounting scheme is evidence-oriented (what a given study demonstrates); Section 6.4 complements it with a mechanism-design taxonomy of six electricity--carbon coupling *archetypes* (Table VI) that classifies how the literature as a whole structures the coupling, independent of what any single study happens to report.

## 9.2 The remaining review-level gap

Taken together with \[5\], \[21\], \[38\], and \[43\]--\[45\], the evidence indicates that primary research on electricity--carbon coupling is accelerating faster than review-level synthesis of its methodology. We did not identify, in the course of this review's search, a dedicated review focused specifically on carbon-accounting boundaries, dynamic emission-factor treatment, or the interaction between carbon-price volatility and electricity-bidding uncertainty. This remains, in our assessment, the most defensible and currently supported gap this review can claim in its carbon-market discussion.

## 9.3 A sharper statement of the gap: the missing VPP-level two-market model

The evidence in Sections 9.1--9.2 supports a more specific version of the carbon gap, worth stating explicitly because it converts a general observation ("carbon coupling is under-reviewed") into a concrete, buildable research target. At the generation-fleet and market-design level, work on the coupling between carbon-trading and tradable-green-certificate mechanisms under electricity marketization shows that these two instruments interact through investment behavior and price formation in ways that a single-instrument model misses \[77\], and this fleet/policy-level coupling logic is structurally the same two-market problem --- jointly manage an energy position and a carbon-related position under correlated uncertainty --- that a VPP-level model would need. At the aggregator level, by contrast, the coding in Table IX shows that most carbon-integrated studies treat the carbon price as a fixed scalar in the objective (archetypes A1--A2, Section 6.4; coupling levels 1--2, Section 9.1) rather than as a traded, uncertain position; explicit allowance buy/bank/sell decisions alongside the energy bid, with carbon price treated as a full uncertainty object rather than a constant, are essentially absent from the verified core. The missing piece is therefore not a new algorithm --- two-market stochastic and DRO programming already exists in the fleet/policy-coupling literature \[21\], \[25\], \[77\], and border-carbon-pricing analysis shows the same "price on a subset of the generation mix" logic extends naturally to trade-exposed operation \[76\] --- but its transplantation to the aggregator, where the portfolio is smaller, the assets are behind the meter, and the carbon-displacement claim is only as credible as the metering that supports it (Section 6.2, L1). This framing of the gap is corroborated by convergent findings across the electricity--carbon literature \[5\], \[77\], which strengthens confidence that it reflects a structural gap rather than an artifact of this review\'s search strategy or verified core.

# 10. Results: Maturity, Out-of-Sample Validity, and Reproducibility

## 10.1 Central finding: information-to-settlement validation, not algorithmic sophistication, is the binding constraint

We propose the following as the central finding of this review, directly supported by the verified-core coding: the principal weakness of contemporary VPP research is not the absence of advanced optimization or learning methods, but the incomplete validation of the information-to-settlement pathway. Within the verified core, out-of-sample validity is explicit in only 2/39 studies (partial in 5, NR in 32); settlement realism is explicit in only 4/39 (partial in 18, NR in 17); reproducibility is explicit in 0/39 studies (partial in 38, NR in 1). By contrast, decision integrity and market realism are each explicit in over 75% of studies. This asymmetry --- strong evidence at the modeling layer, weak evidence at the validation and settlement layer --- is consistent with, and reinforces, the theory--practice gap identified independently in \[4\]. The same asymmetry can be read the other way round: the literature compares VPP decision-method families far more often on revenue than on auditability, which mirrors, from a different angle, this review\'s own Optimization-to-Settlement Evidence Gap (Section 8.3).

We restate the caveat from Section 2.7 here because it is directly relevant to this finding: these counts come from a single structured-coding pass that has not yet been independently double-coded, so they should be read as indicative of a pattern, not as a precise, externally validated prevalence estimate. We consider the direction of the pattern (O and R far weaker than I, D, and M) more robust than the exact counts, because it recurs consistently across the market/settlement (Table VIII), carbon (Table IX), and AI/forecasting (Table XI) evidence groupings independently.

![Fig. 5. DMDI evidence matrix, verified core (E = explicit; P = partial; NR = not reported/not established from available evidence).](media/image5.png){width="5.833333333333333in" height="6.380067804024497in"}

Fig. 5. DMDI evidence matrix, verified core (E = explicit; P = partial; NR = not reported/not established from available evidence).

### TABLE X --- DMDI evidence coverage in the 39-study verified core

  -----------------------------------------------------------------------------------------------------------------------
  DMDI dimension                    Explicit   Partial   NR (combined; NR-R/NR-U split pending re-tagging, Section 5.3)
  --------------------------------- ---------- --------- ----------------------------------------------------------------
  I --- Information-set integrity   22         17        0

  U --- Uncertainty integrity       23         15        1

  D --- Decision integrity          32         7         0

  M --- Market realism              31         8         0

  O --- Out-of-sample validity      2          5         32

  S --- Settlement realism          4          18        17

  R --- Reproducibility             0          38        1

  P --- Deployment maturity         2          5         32
  -----------------------------------------------------------------------------------------------------------------------

## 10.2 AI/forecasting evidence and the forecast-to-value pathway

### TABLE XI --- AI/forecasting evidence and the forecast-to-value pathway

  -----------------------------------------------------------------------------------------------------------------------------------
  Study                                   AI/forecasting role                              I          D          OOS       Maturity
  --------------------------------------- ------------------------------------------------ ---------- ---------- --------- ----------
  Sadeghi et al. (2021) \[11\]            BiLSTM + day-ahead energy/frequency regulation   Explicit   Explicit   Partial   Level 4

  Sadeghi Gougheri et al. (2021) \[12\]   BiLSTM + energy/spinning reserve                 Explicit   Explicit   Partial   Level 4

  Wang et al. (2024) \[19\]               Adversarial GNN for data-scarce PV forecasting   Explicit   Partial    NR        Level 2

  Xu et al. (2024) \[23\]                 Model-assisted MARL                              Partial    Explicit   NR        Level 1

  Wu et al. (2024) \[24\]                 Adaptive MARL                                    Partial    Explicit   NR        Level 1

  Nadimi & Goto (2025) \[29\]             Forecast correction, day-ahead to balancing      Explicit   Explicit   Partial   Level 3

  Nadimi & Goto (2025) \[30\]             DSS-BiLSTM, 38-hour day-ahead forecast           Explicit   Partial    Partial   Level 3
  -----------------------------------------------------------------------------------------------------------------------------------

A conceptual distinction worth foregrounding, consistent with critiques in the broader forecasting-and-decision literature and echoed in \[1\], is that forecast accuracy and realized decision value are not interchangeable evidence claims. Because balancing markets frequently apply asymmetric imbalance prices, a bidding policy built on a slightly less accurate but imbalance-aware forecast can outperform, in realized market value, a policy built on a more accurate but imbalance-agnostic point forecast. We propose this forecast-to-decision-value distinction as an interpretive lens for this review rather than as an already-quantified literature-wide finding.

## 10.3 The Data-to-Market Maturity Ladder

To compare heterogeneous studies without collapsing methodological novelty and validation maturity into one axis, we use an eight-level ladder. The ladder describes the strength of empirical validation and deployment evidence, not the scientific quality of an algorithm in isolation --- a Level 1 conceptual DRO formulation is not thereby a weaker piece of mathematics than a Level 6 heuristic pilot; it simply carries different evidence for deployment claims.

### TABLE XII --- Data-to-Market Maturity Ladder coding rules

  --------------------------------------------------------------------------------------------------------------
  Level   Status                   Minimum evidence expectation
  ------- ------------------------ -----------------------------------------------------------------------------
  0       Conceptual               Architecture or formulation without empirical validation

  1       Synthetic simulation     Synthetic or fully assumed data with computational demonstration

  2       Historical-data study    Historical measurements or market data used for evaluation

  3       Temporal out-of-sample   Chronological train/test separation or rolling evaluation

  4       Market-realistic         Explicit market timing, products, constraints, realistic bidding/clearing

  5       Settlement-aware         Deviation, imbalance, penalty, or settlement/accounting mechanisms modeled

  6       Pilot validation         Evidence from a pilot, field demonstration, or operational test environment

  7       Operational deployment   Sustained real-world operation with documented performance
  --------------------------------------------------------------------------------------------------------------

![Fig. 6. Data-to-Market Maturity Ladder coverage in the verified core.](media/image6.png){width="4.819549431321085in" height="2.7222812773403327in"}

Fig. 6. Data-to-Market Maturity Ladder coverage in the verified core.

Based on the verified core, the literature clusters predominantly at Levels 1--4; few studies (e.g., \[8\], \[9\], \[16\]) reach Level 4, and none of the studies tabulated in Tables VII--XI is coded above Level 4, i.e., no tabulated study reaches the settlement-aware, pilot, or operational-deployment rungs (Levels 5--7). A precise quantitative distribution across the full literature is deferred until database-level screening (Section 2.4) is completed; the qualitative clustering pattern, however, is consistent across every evidence table in Sections 7--10.

# 11. Cross-Layer Evidence Gaps and a Research Agenda

![Fig. 7. Evolution of VPP research themes across the data-to-market chain. The plot is descriptive and is not a prevalence estimate for the full literature.](media/image7.png){width="4.4447309711286085in" height="2.5140507436570427in"}

Fig. 7. Evolution of VPP research themes across the data-to-market chain. The plot is descriptive and is not a prevalence estimate for the full literature.

![](media/image8.png){width="4.4405686789151355in" height="3.6041666666666665in"}

Fig. 8. DMDI validation stack. Forecast and algorithmic performance are progressively tested against decision, market, settlement, and deployment constraints.

## 11.1 Evidence bottlenecks in the data-to-market chain

Reading Tables X--XII together produces a consistent picture: information (I), decision (D), and market (M) integrity are comparatively strong; out-of-sample validity (O), settlement realism (S), and reproducibility (R) are comparatively weak, with uncertainty integrity (U) in between. This is not an artifact of any single evidence table --- it recurs in the uncertainty/decision comparison (Table VII), the market/settlement/carbon comparison (Tables VIII--IX), and the AI/forecasting comparison (Table XI) independently. This pattern also mirrors the Layer 1--4 maturity ratings of the complementary Decision Integrity framework (Section 6.2): DMDI's O/S/R weaknesses correspond closely to the Execution- and Governance-layer gaps identified there. We treat closing the O/S/R gap, rather than further algorithmic refinement of I/D/M, as the most consequential direction for the field (Section 11.2--11.6).

## 11.2 Information-set integrity as a reporting requirement

Future studies should explicitly define the information available at every decision point --- measurement timestamps, forecast publication times, market gate closure, asset availability, and prices observed before bidding --- ideally via a decision-time information table or equivalent machine-readable description. This directly addresses look-ahead bias and makes temporal causality auditable by a third party.

## 11.3 From uncertainty representation to uncertainty validation

Stochastic, robust, DRO, and risk-averse formulations should be evaluated not only by their mathematical treatment of uncertainty but by empirical uncertainty-model quality: calibration, coverage, dependence preservation, temporal correlation, tail behavior, scenario-reduction distortion, and out-of-sample risk.

## 11.4 From AI accuracy to decision and market value

AI studies should report a hierarchy of evidence --- predictive metrics, operational metrics, bidding metrics, realized market metrics --- and prefer temporal hold-out tests to random splits for time-dependent market data. Regime-shift tests and ablations are especially valuable when AI is embedded in optimization or bidding.

## 11.5 Settlement realism and an expanded benchmark metric set

VPP market studies should represent the actual sequence of market decisions relevant to the modeled jurisdiction, and where imbalance settlement is material, should report scheduled energy, delivered energy, deviations, penalties, and settlement prices as distinct quantities (Section 8.3). We propose the following reporting set:

### TABLE XIII --- Decision-integrity metrics proposed for future benchmarking

  ----------------------------------------------------------------------------------------------------------------------------------------------------------------------
  Metric                                    Layer                         Definition                                                                      DMDI linkage
  ----------------------------------------- ----------------------------- ------------------------------------------------------------------------------- --------------
  Out-of-sample forecast error (MAE/RMSE)   Forecasting                   Error on chronologically unseen data                                            O

  Calibration error / PICP                  Forecasting (probabilistic)   Deviation between nominal and empirical prediction-interval coverage            U

  Interval width                            Forecasting (probabilistic)   Mean width of predictive intervals at a stated coverage level                   U

  CRPS                                      Forecasting (probabilistic)   Continuous ranked probability score against realized outcomes                   U

  Scenario correlation error                Uncertainty                   Discrepancy between scenario-set dependence and empirical dependence            U

  Tail dependence error                     Uncertainty                   Discrepancy between scenario-set tail co-movement and empirical tail behavior   U

  Profit volatility                         Economic risk                 σ(profit) across OOS periods/scenarios                                          MV/Risk

  CVaR95                                    Tail risk                     Expected loss conditional on the worst 5% of outcomes                           U/D

  Schedule--execution match                 Decision integrity            \|E_actual − E_scheduled\| / E_scheduled × 100                                  D

  Bid acceptance rate                       Market realism                Share of submitted bids/offers cleared                                          M

  Imbalance volume                          Settlement                    Total scheduled-vs-delivered deviation volume                                   S

  Relative deviation cost                   Settlement                    Deviation penalty ÷ total realized profit × 100                                 S

  Real-time settlement cost                 Settlement                    Adjustment cost + imbalance/penalty payments                                    S

  Uplift/settlement discrepancy             Settlement                    Difference between objective-value profit and settled profit                    S

  Constraint violation rate                 Decision/market integrity     Count or rate of physical/market constraint violations                          D/M

  Decision latency                          Deployment                    T_execution − T_decision                                                        P/D

  Computational time                        Deployment                    Wall-clock solve time per decision instance                                     P

  Memory / inference latency                Deployment                    Peak memory and per-inference latency for learned policies                      P
  ----------------------------------------------------------------------------------------------------------------------------------------------------------------------

These metrics are reporting variables, not a composite score, and should be reported separately because they measure distinct failure modes.

## 11.6 Reproducibility and coding-reliability roadmap

Beyond study-level reproducibility (open data, code, and parameterization --- Section 5.1), we identify the review's own coding reproducibility as an explicit, near-term task: (i) complete the institutional-account database run specified in Table I and freeze the PRISMA identification/screening/eligibility counts; (ii) recruit a second, blinded coder to re-apply the DMDI and Q1--Q8 instruments to the verified core and report agreement (e.g., Cohen's κ or Krippendorff's α) per dimension; (iii) retrospectively re-tag existing NR entries as NR-R or NR-U (Section 5.3); (iv) only after (i)--(iii), consider whether any numerical DMDI summary beyond the per-dimension counts in Table X is warranted. Until then, this review presents its own quantitative statements with the same caution it applies to the primary literature it reviews.

## 11.7 Electricity--carbon coupling beyond objective-function aggregation

Carbon integration should be reported at the six accounting levels in Section 9.1 and positioned against the six coupling archetypes in Section 6.4, not merely as present/absent. Level 5--6 evidence (carbon-market clearing and settlement-coupled decisions) and Archetype A4--A6 mechanisms provide the strongest support for claims about coupled electricity--carbon value, because market timing, constraints, prices, and settlement interact directly with electricity-market decisions.

# 12. Limitations

Several limitations qualify every claim in this review. First, and most importantly, database-level identification, deduplication, and screening counts are not yet frozen (Section 2.4); Table I\'s record counts and search dates remain explicit placeholders pending institutional-account access, and the review is titled and framed accordingly as a structured, PRISMA-informed evidence review rather than a completed PRISMA systematic review. Second, structured coding has not yet been independently double-coded; the DMDI and maturity-ladder counts reported in Sections 7--10 should be read as indicative of a pattern rather than as externally validated prevalence statistics, and closing this gap is the first item of the research agenda (Section 11.6). Third, the NR-R/NR-U distinction introduced in Section 5.3 has been applied only prospectively; the existing 39-study matrix (Table X) reports a combined NR column pending a re-tagging pass. Fourth, the complementary Decision Integrity framework introduced in Section 6 is a conceptual, literature-wide threat-and-maturity taxonomy, not a per-study coded instrument like DMDI; its layer-maturity ratings (Table III) are illustrative judgments by the authors rather than counts derived from the verified core, and should not be read as having the same evidentiary status as the DMDI tables in Sections 7--10. Fifth, heterogeneity in VPP definitions, market structures, datasets, horizons, and evaluation objectives limits direct meta-analysis for many technical metrics; the review therefore emphasizes structured evidence synthesis over pooled effect sizes. Sixth, coverage --- while spanning architecture, uncertainty, AI, market, and carbon streams --- is not exhaustive for a 2018--2026 window; in particular, European market-design variants, probabilistic scenario-generation methodology, and hardware-in-the-loop validation studies are comparatively under-represented in the current verified core and are natural targets for the completed database screening. Seventh, DMDI, the Decision Integrity framework, and the maturity ladder are proposed by this review and are not established external standards; their purpose is to provide an auditable structure for comparing evidence quality across heterogeneous VPP studies, not to rank individual papers or algorithms (Section 12.1). Eighth, the reference list was verified against Crossref and publisher DOI records, and every entry resolves to a real, independently locatable publication; verification of metadata is nevertheless a point-in-time check, since volume, issue, and page details for very recent articles can change between online-first and issue publication.

## 12.1 Boundary conditions for interpretation

The DMDI dimensions are designed to expose missing evidence and support transparent comparison across heterogeneous studies; they do not imply that every VPP application requires the same market products, settlement mechanism, or validation depth. The maturity ladder describes the strength of empirical validation and deployment evidence, not the scientific quality of an algorithm in isolation --- a synthetic-simulation study using a genuinely novel formulation and a settlement-aware pilot study using a comparatively simple heuristic occupy different rungs of the ladder for reasons that have nothing to do with which is the better piece of applied mathematics.

# 13. Conclusion

VPP research is increasingly data-driven, uncertainty-aware, AI-enabled, and market-oriented. The consequential question is whether an improvement survives the complete data-to-market chain. This review shifts the unit of analysis from the isolated algorithm to decision integrity: what information was available, how uncertainty was represented, how the decision was produced, how the bid interacted with the market, how deviations were settled, and what economic or carbon value was realized.

Within the limits stated in Section 12 --- most importantly, that database-level screening is not yet frozen and that structured coding has not yet been independently double-coded --- the verified-core evidence supports a consistent pattern: information-set, decision, and market integrity are comparatively well reported in the 2018--2026 VPP literature, while out-of-sample validity, settlement realism, and reproducibility are comparatively weak. Electricity--carbon market coupling is an active but still comparatively under-reviewed methodological frontier, with primary research on joint bidding and carbon-price-linked strategy accelerating faster than dedicated review-level synthesis of its accounting and dynamic-pricing methodology. The proposed DMDI framework and Data-to-Market Maturity Ladder are offered as diagnostic, auditable tools --- not validated external standards --- toward a VPP research agenda that treats settlement-aware benchmarking, chronological out-of-sample evaluation, explicit carbon-accounting-boundary reporting, and coding-level reproducibility as first-class evidence, alongside continued algorithmic innovation.

# 14. References

\[1\] G. Ruan, D. Qiu, S. Sivaranjani, A. S. A. Awad, and G. Strbac, "Data-driven energy management of virtual power plants: A review," *Advances in Applied Energy*, vol. 14, 100170, 2024, doi: 10.1016/j.adapen.2024.100170.

\[2\] H. Gao, T. Jin, C. Feng, C. Li, Q. Chen, and C. Kang, "Review of virtual power plant operations: Resource coordination and multidimensional interaction," *Applied Energy*, vol. 357, 122284, 2024, doi: 10.1016/j.apenergy.2023.122284.

\[3\] M. Kaiss, Y. Wan, D. Gebbran, C. U. Vila, and T. Dragičević, "Review on Virtual Power Plants/Virtual Aggregators: Concepts, applications, prospects and operation strategies," *Renewable and Sustainable Energy Reviews*, vol. 211, 115242, 2025, doi: 10.1016/j.rser.2024.115242.

\[4\] M. Esfahani, A. Alizadeh, B. Cao, I. Kamwa, and M. Xu, "Bridging theory and practice: A comprehensive review of virtual power plant technologies and their real-world applications," *Renewable and Sustainable Energy Reviews*, vol. 222, 115929, 2025, doi: 10.1016/j.rser.2025.115929.

\[5\] A. Zare, M. Shafie-khah, P. Siano, and G. C. Lazaroiu, "A systematic review of Virtual Power Plant configurations and their interaction with electricity, carbon, and flexibility markets," *Renewable and Sustainable Energy Reviews*, vol. 226, art. no. 116448, 2026, doi: 10.1016/j.rser.2025.116448.

\[6\] M. J. Page et al., "The PRISMA 2020 statement: An updated guideline for reporting systematic reviews," *BMJ*, vol. 372, n71, 2021, doi: 10.1136/bmj.n71.

\[7\] N. Naval and J. M. Yusta, "Virtual power plant models and electricity markets --- A review," *Renewable and Sustainable Energy Reviews*, vol. 149, 111393, 2021, doi: 10.1016/j.rser.2021.111393.

\[8\] S. Kim and D. G. Choi, "A sample robust optimal bidding model for a virtual power plant," *European Journal of Operational Research*, vol. 316, no. 3, pp. 1101--1113, 2024, doi: 10.1016/j.ejor.2024.03.001.

\[9\] D. Wozabal and G. Rameseder, "Optimal bidding of a virtual power plant on the Spanish day-ahead and intraday market for electricity," *European Journal of Operational Research*, vol. 280, no. 2, pp. 639--655, 2020, doi: 10.1016/j.ejor.2019.07.022.

\[10\] M. Vahedipour-Dahraie, H. Rashidizadeh-Kermani, A. Anvari-Moghaddam, and P. Siano, "Risk-averse probabilistic framework for scheduling of virtual power plants considering demand response and uncertainties," *International Journal of Electrical Power & Energy Systems*, vol. 121, 106126, 2020, doi: 10.1016/j.ijepes.2020.106126.

\[11\] S. Sadeghi, H. Jahangir, B. Vatandoust, M. A. Golkar, A. Ahmadian, and A. Elkamel, "Optimal bidding strategy of a virtual power plant in day-ahead energy and frequency regulation markets: A deep learning-based approach," *International Journal of Electrical Power & Energy Systems*, vol. 127, 106646, 2021, doi: 10.1016/j.ijepes.2020.106646.

\[12\] S. Sadeghi Gougheri et al., "Optimal participation of a virtual power plant in electricity market considering renewable energy: A deep learning-based approach," *Sustainable Energy, Grids and Networks*, vol. 26, 100448, 2021, doi: 10.1016/j.segan.2021.100448.

\[13\] X. Liu, "Research on bidding strategy of virtual power plant considering carbon-electricity integrated market mechanism," *International Journal of Electrical Power & Energy Systems*, vol. 137, 107891, 2022, doi: 10.1016/j.ijepes.2021.107891.

\[14\] J. Wang, C. Guo, C. Yu, and Y. Liang, "Virtual power plant containing electric vehicles scheduling strategies based on deep reinforcement learning," *Electric Power Systems Research*, vol. 205, art. no. 107714, 2022, doi: 10.1016/j.epsr.2021.107714.

\[15\] Y. Chen, Y. Niu, M. Du, and J. Wang, "A two-stage robust optimization model for a virtual power plant considering responsiveness-based electric vehicle aggregation," *Journal of Cleaner Production*, vol. 405, 136690, 2023, doi: 10.1016/j.jclepro.2023.136690.

\[16\] D. Falabretti, F. Gulotta, and D. Siface, "Scheduling and operation of RES-based virtual power plants with e-mobility: A novel integrated stochastic model," *International Journal of Electrical Power & Energy Systems*, vol. 144, art. no. 108604, 2023, doi: 10.1016/j.ijepes.2022.108604.

\[17\] C. Yang, X. Du, D. Xu, J. Tang, X. Lin, K. Xie, and W. Li, "Optimal bidding strategy of renewable-based virtual power plant in the day-ahead market," *International Journal of Electrical Power & Energy Systems*, vol. 144, 108557, 2023, doi: 10.1016/j.ijepes.2022.108557.

\[18\] S. Mei, Q. Tan, A. Trivedi, and D. Srinivasan, "A two-step optimization model for virtual power plant participating in spot market based on energy storage power distribution considering comprehensive forecasting error of renewable energy output," *Applied Energy*, vol. 376, art. no. 124234, 2024, doi: 10.1016/j.apenergy.2024.124234.

\[19\] Y. Wang, W. Fu, J. Wang, Z. Zhen, and F. Wang, "Ultra-short-term distributed PV power forecasting for virtual power plant considering data-scarce scenarios," *Applied Energy*, vol. 373, 123890, 2024, doi: 10.1016/j.apenergy.2024.123890.

\[20\] R. Liu, K. Chen, G. Sun, S. Lin, and C. Jiang, "Bidding strategy for the virtual power plant based on cooperative game participating in the Electricity-Carbon joint market," *International Journal of Electrical Power & Energy Systems*, vol. 163, 110325, 2024, doi: 10.1016/j.ijepes.2024.110325.

\[21\] Y. Wang, J. Xu, W. Pei, H. Wang, and Z. Zhang, "Low-carbon economic scheduling of virtual power plant considering carbon emission flow and demand response," *Frontiers in Energy Research*, vol. 12, art. no. 1398655, 2024, doi: 10.3389/fenrg.2024.1398655.

\[22\] W. Li, "The virtual power plant bidding strategy model based on multi-stage semi-anticipativity distributionally robust optimization," *Electric Power Systems Research*, vol. 237, 111015, 2024, doi: 10.1016/j.epsr.2024.111015.

\[23\] B. Xu, W. Luan, J. Yang, B. Zhao, C. Long, Q. Ai, and J. Xiang, "Integrated three-stage decentralized scheduling for virtual power plants: A model-assisted multi-agent reinforcement learning method," *Applied Energy*, vol. 376, 123985, 2024, doi: 10.1016/j.apenergy.2024.123985.

\[24\] H.-C. Wu, D. Qiu, L. Zhang, and M. Sun, "Adaptive multi-agent reinforcement learning for flexible resource management in a virtual power plant with dynamic participating multi-energy buildings," *Applied Energy*, vol. 374, 123998, 2024, doi: 10.1016/j.apenergy.2024.123998.

\[25\] Q. Fan and D. Liu, "A Wasserstein-distance-based distributionally robust chance-constrained bidding model for virtual power plant considering electricity-carbon trading," *IET Renewable Power Generation*, vol. 18, no. 3, pp. 545--557, 2024, doi: 10.1049/rpg2.12907.

\[26\] W. Li, F. Dong, Z. Ji, and P. Wang, "Internal and external coordinated distributionally robust bidding strategy of virtual power plant operator participating in day-ahead electricity spot and peaking ancillary services markets," *Applied Energy*, vol. 386, art. no. 125514, 2025, doi: 10.1016/j.apenergy.2025.125514.

\[27\] Y. Ma, Z. Li, R. Liu, B. Liu, S. S. Yu, X. Liao, and P. Shi, "Data-driven interval robust optimization method of VPP bidding strategy in spot market under multiple uncertainties," *Applied Energy*, vol. 384, art. no. 125366, 2025, doi: 10.1016/j.apenergy.2025.125366.

\[28\] C. Song, Y. Yuan, and L. Dai, "Distributionally robust optimization of virtual power plant bidding strategies considering discrete scenario-based uncertainties in day-ahead market prices and wind powers," *Electric Power Systems Research*, vol. 248, 111977, 2025, doi: 10.1016/j.epsr.2025.111977.

\[29\] R. Nadimi and M. Goto, "Uncertainty reduction in power forecasting of virtual power plant: From day-ahead to balancing markets," *Renewable Energy*, vol. 238, 121875, 2025, doi: 10.1016/j.renene.2024.121875.

\[30\] R. Nadimi and M. Goto, "A novel decision support system for enhancing long-term forecast accuracy in virtual power plants using bidirectional long short-term memory networks," *Applied Energy*, vol. 382, 125273, 2025, doi: 10.1016/j.apenergy.2025.125273.

\[31\] J. Bian, J. Cheng, H. Wang, G. Li, and S. Li, "CVaR-based bi-level bidding strategy for VPP to participate in energy-regulation-carbon markets," *International Journal of Electrical Power & Energy Systems*, vol. 174, 111555, 2026, doi: 10.1016/j.ijepes.2025.111555.

\[32\] P. Mo, K. Li, Y. Lu, Y. Wen, and K. Huang, "Deep reinforcement learning-based bidding strategies for virtual power plants in electricity spot markets: A review," *IEEE Access*, vol. 14, pp. 50628--50643, 2026, doi: 10.1109/ACCESS.2026.3678911.

\[33\] H. Zhu, Z. Zhang, Y. Gao, X. Hu, Y. Cai, Y. Wang, Q. Wang, and Q. Ai, "Application of deep learning in virtual power plants --- A review," *Energy Internet*, vol. 3, no. 2, pp. 97--110, 2026, doi: 10.1049/ein2.70027.

\[34\] J. Li, C. Wang, and Y. Liu, "AI-driven virtual power plants: A comprehensive review," *Energies*, vol. 19, no. 4, 1084, 2026, doi: 10.3390/en19041084.

\[35\] H. Bhattarai, A. Aziz, and S. W. Lachowicz, "Policy and regulation in virtual power plants development," *Utilities Policy*, vol. 101, art. no. 102212, 2026, doi: 10.1016/j.jup.2026.102212.

\[36\] Y. Song, Y. Chu, Y. Yoon, and Y. Jin, "Virtual power plant bidding strategies in pay-as-bid and pay-as-clear markets: Analysis of imbalance penalties and market operations," *Energies*, vol. 18, no. 6, art. no. 1383, 2025, doi: 10.3390/en18061383.

\[37\] E. J. Choi, G.-S. Seo, and S. W. Kim, "Are better combinations of DERs more profitable? Combinatorial optimization for aggregation of DERs in wholesale electricity markets," *Applied Energy*, vol. 396, art. no. 126264, 2025, doi: 10.1016/j.apenergy.2025.126264.

\[38\] G. Wang, Z. Lin, Y. Chen, R. Qiu, H. Zhang, and J. Yan, "Carbon-billed future for virtual power plants: A comprehensive review," *Renewable and Sustainable Energy Reviews*, vol. 217, art. no. 115719, 2025, doi: 10.1016/j.rser.2025.115719.

\[39\] A. Bedi, J. Ramprabhakar, R. Anand, V. P. Meena, and I. A. Hameed, "Empowering net zero energy grids: A comprehensive review of virtual power plants, challenges, applications, and blockchain integration," *Discover Applied Sciences*, vol. 7, art. no. 252, 2025, doi: 10.1007/s42452-025-06691-1.

\[40\] P. Bendigiri and P. Rao, "A critical review of virtual power plants for distributed renewable energy projects in the built environment," *Discover Sustainability*, vol. 7, art. no. 798, 2026, doi: 10.1007/s43621-026-03202-z.

\[41\] M. Esfahani, A. Alizadeh, N. Amjady, and I. Kamwa, "A distributed VPP-integrated co-optimization framework for energy scheduling, frequency regulation, and voltage support using data-driven distributionally robust optimization with Wasserstein metric," *Applied Energy*, vol. 361, 122883, 2024, doi: 10.1016/j.apenergy.2024.122883.

\[42\] Y. Li, W. Chang, and Q. Yang, "Deep reinforcement learning based hierarchical energy management for virtual power plant with aggregated multiple heterogeneous microgrids," *Applied Energy*, vol. 382, 125333, 2025, doi: 10.1016/j.apenergy.2025.125333.

\[43\] Z. Siqin, R. Diao, and M. Zhao, "Two-stage distributionally robust bidding strategies for multi-energy virtual power plants in energy, reserve and carbon markets," *Energy*, vol. 334, 137455, 2025, doi: 10.1016/j.energy.2025.137455.

\[44\] K. N. Singh, A. K. Goswami, N. B. D. Choudhury, et al., "A risk-aware bidding model for virtual power plants: Integrating renewable energy forecasting and carbon market strategies," *Energy Reports*, vol. 14, pp. 1222--1239, 2025, doi: 10.1016/j.egyr.2025.07.032.

\[45\] J. Jin, X. Pang, B. Wang, D. Wang, and Z. Zheng, "Optimal scheduling method of carbon-green certificate trading virtual power plant via Q-learning-enhanced particle swarm algorithm," *Complex & Intelligent Systems*, vol. 12, art. 51, 2026, doi: 10.1007/s40747-025-02176-1.

\[46\] L. Xie, G. Li, M. Xu, X. Dong, and Z. Tan, "Optimizing virtual power plant coordination through locational marginal flexibility under network constraints," *Scientific Reports*, vol. 16, 3789, 2026, doi: 10.1038/s41598-025-33726-9.

\[47\] S. Zhang, W. Deng, Y. Zhang, Z. Jing, N. Guo, J. Yu, B. Wang, and M. Liao, "A multi-agent closed-loop decision-making framework for joint forecasting and bidding in electricity spot markets," *Energies*, vol. 18, art. no. 6486, 2025, doi: 10.3390/en18246486.

\[48\] K. N. Singh, A. K. Goswami, N. B. D. Choudhury, T. S. Ustun, and U. Cali, "Virtual power plants in modern power systems: A comprehensive review of uncertainty management and market bidding strategies," *IEEE Access*, vol. 14, pp. 75331--75355, 2026, doi: 10.1109/ACCESS.2026.3691418.

\[49\] G. Zhang, C. Jiang, and X. Wang, "Comprehensive review on structure and operation of virtual power plant in electrical system," *IET Generation, Transmission & Distribution*, vol. 13, pp. 145--156, 2019, doi: 10.1049/iet-gtd.2018.5880.

\[50\] L. Yavuz, A. Önen, S. M. Muyeen, and I. Kamwa, "Transformation of microgrid to virtual power plant --- A comprehensive review," *IET Generation, Transmission & Distribution*, vol. 13, pp. 1994--2005, 2019, doi: 10.1049/iet-gtd.2018.5649.

\[51\] M. Rahimiyan and L. Baringo, "Real-time energy management of a smart virtual power plant," *IET Generation, Transmission & Distribution*, vol. 13, pp. 2015--2023, 2019, doi: 10.1049/iet-gtd.2018.5637.

\[52\] M. Mousavi, M. Rayati, and A. M. Ranjbar, "Optimal operation of a virtual power plant in frequency constrained electricity market," *IET Generation, Transmission & Distribution*, vol. 13, pp. 2123--2133, 2019, doi: 10.1049/iet-gtd.2018.5204.

\[53\] M. Shafiekhani, A. Badri, M. Shafie-khah, and J. P. S. Catalão, "Strategic bidding of virtual power plant in energy markets: A bi-level multi-objective approach," *International Journal of Electrical Power & Energy Systems*, vol. 113, pp. 208--219, 2019, doi: 10.1016/j.ijepes.2019.05.023.

\[54\] J. Hu, C. Jiang, and Y. Liu, "Short-term bidding strategy for a price-maker virtual power plant based on interval optimization," *Energies*, vol. 12, no. 19, 3662, 2019, doi: 10.3390/en12193662.

\[55\] Z. Luo, S. Hong, and Y. Ding, "A data mining-driven incentive-based demand response scheme for a virtual power plant," *Applied Energy*, vol. 239, pp. 549--559, 2019, doi: 10.1016/j.apenergy.2019.01.142.

\[56\] Y. Liu, P. Ning, and M. K. Reiter, "False data injection attacks against state estimation in electric power grids," *ACM Transactions on Information and System Security*, vol. 14, no. 1, art. 13, 2011, doi: 10.1145/1952982.1952995.

\[57\] G. Liang, J. Zhao, F. Luo, S. R. Weller, and Z. Y. Dong, "A review of false data injection attacks against modern power systems," *IEEE Transactions on Smart Grid*, vol. 8, no. 4, pp. 1630--1638, 2017, doi: 10.1109/TSG.2015.2495133.

\[58\] I. J. Goodfellow, J. Shlens, and C. Szegedy, "Explaining and harnessing adversarial examples," in *Proc. Int. Conf. Learning Representations (ICLR)*, San Diego, CA, USA, 2015.

\[59\] S. M. Lundberg and S.-I. Lee, "A unified approach to interpreting model predictions," in *Proc. Advances in Neural Information Processing Systems (NeurIPS)*, Long Beach, CA, USA, 2017, pp. 4765--4774.

\[60\] M. T. Ribeiro, S. Singh, and C. Guestrin, "'Why should I trust you?': Explaining the predictions of any classifier," in *Proc. ACM SIGKDD Int. Conf. Knowledge Discovery and Data Mining*, San Francisco, CA, USA, 2016, pp. 1135--1144, doi: 10.1145/2939672.2939778.

\[61\] H. B. McMahan, E. Moore, D. Ramage, S. Hampson, and B. A. y Arcas, "Communication-efficient learning of deep networks from decentralized data," in *Proc. Int. Conf. Artificial Intelligence and Statistics (AISTATS)*, Fort Lauderdale, FL, USA, 2017, pp. 1273--1282.

\[62\] F. Tao, H. Zhang, A. Liu, and A. Y. C. Nee, "Digital twin in industry: State-of-the-art," *IEEE Transactions on Industrial Informatics*, vol. 15, no. 4, pp. 2405--2415, 2019, doi: 10.1109/TII.2018.2873186.

\[63\] M. Andoni et al., "Blockchain technology in the energy sector: A systematic review of challenges and opportunities," *Renewable and Sustainable Energy Reviews*, vol. 100, pp. 143--174, 2019, doi: 10.1016/j.rser.2018.10.014.

\[64\] P. Mohajerin Esfahani and D. Kuhn, "Data-driven distributionally robust optimization using the Wasserstein metric: Performance guarantees and tractable reformulations," *Mathematical Programming*, vol. 171, nos. 1--2, pp. 115--166, 2018, doi: 10.1007/s10107-017-1172-1.

\[65\] S. Boyd, N. Parikh, E. Chu, B. Peleato, and J. Eckstein, "Distributed optimization and statistical learning via the alternating direction method of multipliers," *Foundations and Trends in Machine Learning*, vol. 3, no. 1, pp. 1--122, 2011, doi: 10.1561/2200000016.

\[66\] J. F. Benders, "Partitioning procedures for solving mixed-variables programming problems," *Numerische Mathematik*, vol. 4, no. 1, pp. 238--252, 1962, doi: 10.1007/BF01386316.

\[67\] J. F. Nash, "Non-cooperative games," *Annals of Mathematics*, vol. 54, no. 2, pp. 286--295, 1951, doi: 10.2307/1969529.

\[68\] L. S. Shapley, "A value for n-person games," in *Contributions to the Theory of Games*, vol. 2, H. W. Kuhn and A. W. Tucker, Eds. Princeton, NJ, USA: Princeton Univ. Press, 1953, pp. 307--317.

\[69\] R. T. Rockafellar and S. Uryasev, "Optimization of conditional value-at-risk," *Journal of Risk*, vol. 2, no. 3, pp. 21--41, 2000, doi: 10.21314/JOR.2000.038.

\[70\] Y. Ben-Haim, *Info-Gap Decision Theory: Decisions Under Severe Uncertainty*, 2nd ed. Oxford, U.K.: Academic Press, 2006.

\[71\] J. R. Birge and F. Louveaux, *Introduction to Stochastic Programming*, 2nd ed. New York, NY, USA: Springer, 2011, doi: 10.1007/978-1-4614-0237-4.

\[72\] A. Charnes and W. W. Cooper, "Chance-constrained programming," *Management Science*, vol. 6, no. 1, pp. 73--79, 1959, doi: 10.1287/mnsc.6.1.73.

\[73\] D. Bertsimas and M. Sim, "The price of robustness," *Operations Research*, vol. 52, no. 1, pp. 35--53, 2004, doi: 10.1287/opre.1030.0065.

\[74\] A. Ben-Tal, L. El Ghaoui, and A. Nemirovski, *Robust Optimization*. Princeton, NJ, USA: Princeton Univ. Press, 2009.

\[75\] Q. Zhang, F. Li, Q. Shi, K. Tomsovic, J. Sun, and L. Ren, "Profit-oriented false data injection on electricity market: Reviews, analyses, and insights," *IEEE Transactions on Industrial Informatics*, vol. 17, no. 9, pp. 5876--5886, 2021, doi: 10.1109/TII.2020.3036104.

\[76\] C. Böhringer, C. Fischer, K. E. Rosendahl, and T. F. Rutherford, "Potential impacts and challenges of border carbon adjustments," *Nature Climate Change*, vol. 12, no. 1, pp. 22--29, 2022, doi: 10.1038/s41558-021-01250-z.

\[77\] X. Chang, Z. Wu, J. Wang, X. Zhang, M. Zhou, T. Yu, and Y. Wang, "The coupling effect of carbon emission trading and tradable green certificates under electricity marketization in China," *Renewable and Sustainable Energy Reviews*, vol. 187, 113750, 2023, doi: 10.1016/j.rser.2023.113750.
