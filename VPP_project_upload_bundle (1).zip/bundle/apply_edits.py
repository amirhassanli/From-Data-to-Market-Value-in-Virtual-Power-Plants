"""Edits applied to the 2026-10-27 revised manuscript (docx XML), in order.
Usage: unzip docx -> run on word/document.xml -> re-zip. Each replacement asserts a unique match."""
import re
p='un/word/document.xml'; x=open(p,encoding='utf8').read()
def rep(old,new,count=1):
    global x; assert x.count(old)==count,(old,x.count(old)); x=x.replace(old,new)
rep('A companion, deliberately distinct risk-of-bias/evidence-quality layer is proposed for future study-level scoring.',
    'A companion, deliberately distinct risk-of-bias/evidence-quality layer is applied illustratively to three comparator studies and proposed for full study-level scoring.')
rep('[8] S. Kim and H. Choi,','[8] S. Kim and D. G. Choi,')
rep('[44] Y. Wang, J. Xu, W. Pei, H. Wang, and Z. Zhang, “A risk-aware','[44] K. N. Singh, A. K. Goswami, N. B. D. Choudhury, et al., “A risk-aware')
rep('Wang et al.\xa0(2025) [44]','Singh et al.\xa0(2025) [44]')
old='Song et al.\xa0(2025) [28]'; i=x.index(old); j=x.index(old,i+1)
x=x[:j]+'Song et al.\xa0(2025) [36]'+x[j+len(old):]   # Table VIII row -> [36]
# (Section 10.3 sentence and citation insertions for refs 7,15,17,18,32-35,39-42,46-48,52-55: see manuscript)
mp={'1':'2','2':'1','3':'3','4':'6','5':'4','6':'5','7':'7','8':'8'}
x=re.sub(r'Fig\. ([1-8])(?!\d)',lambda m:'Fig. '+mp[m.group(1)],x)
open(p,'w',encoding='utf8').write(x)
